package communication;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.Map;

import com.sun.net.httpserver.HttpHandler;

import AESIBE.IBEBasicIdent;
import AESIBE.KeyPair;
import AESIBE.SettingParameters;
import it.unisa.dia.gas.jpbc.Element;
import it.unisa.dia.gas.jpbc.Pairing;
import it.unisa.dia.gas.plaf.jpbc.pairing.PairingFactory;

import com.sun.net.httpserver.HttpExchange;




class InitHandler implements HttpHandler {
    @Override
    public void handle(HttpExchange exchange) throws IOException {
    	// Lire les données de la requête pour extraire l'e-mail du client
        BufferedReader reader = new BufferedReader(new InputStreamReader(exchange.getRequestBody()));
        StringBuilder requestData = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            requestData.append(line);
        }
        reader.close();
        
        // Extraire l'e-mail des données de la requête
        String[] requestDataParts = requestData.toString().split("&");
        String email = "";
        for (String part : requestDataParts) {
            String[] keyValue = part.split("=");
            if (keyValue.length == 2 && keyValue[0].equals("email")) {
                email = keyValue[1];
                break;
            }
        }
        
        Pairing pairing = PairingFactory.getPairing("C:\\\\Users\\\\oumai\\\\Downloads\\\\jpbc-2.0.0\\\\src\\\\params\\\\curves\\\\a.properties");
        // Convertir l'objet Pairing en une représentation textuelle ou binaire
        String pairingString = pairing.toString();
        SettingParameters sp = IBEBasicIdent.setup(pairing);
        KeyPair keys = null;
        try {
			keys = IBEBasicIdent.keygen(pairing, sp.getMsk(), email);
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		}
      
        // Créer une structure de données pour regrouper tous les objets à envoyer
        Map<String, Object> responseData = new HashMap<>();
        responseData.put("pairing", pairing);
        responseData.put("sp", sp);
        responseData.put("keys", keys);
        
        try {
            exchange.sendResponseHeaders(200, 0);
            OutputStream os = exchange.getResponseBody();
            ObjectOutputStream oos = new ObjectOutputStream(os);
            oos.writeObject(responseData);
            oos.flush();
            oos.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        
     
        // Construire la réponse en concaténant toutes les informations
       // String response = generator.toString() + ";" + clepubsyst.toString() + ";" + privatekey.toString() + ";" + publickey;

        // Envoyer la réponse
        // Envoyer les objets en tant qu'objets sérialisés
     /*   try {
        exchange.sendResponseHeaders(200, 0);
        OutputStream os = exchange.getResponseBody();
        ObjectOutputStream oos = new ObjectOutputStream(os);
       // oos.writeObject(pairing);
       /* oos.writeObject(pairingString);
        oos.writeObject(sp);
        oos.writeObject(keys);*/
       /* oos.flush();
        oos.close();
        } catch (IOException e) {
            e.printStackTrace();
        }*/
        
 
        
        //String response = "Server connected to client"+email ;
        //String response = email ;
       /* exchange.sendResponseHeaders(200, response.getBytes().length);
        OutputStream os = exchange.getResponseBody();
        os.write(response.getBytes());
        os.close();*/
    }
}

