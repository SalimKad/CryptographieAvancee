package communication;
import AESIBE.KeyPair;
import AESIBE.SettingParameters;
import it.unisa.dia.gas.jpbc.Pairing;

import java.io.Serializable;

public class ServerResponse implements Serializable {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Pairing pairing;
    private SettingParameters settingParameters;
    private KeyPair keyPair;

    public ServerResponse(Pairing pairing, SettingParameters settingParameters, KeyPair keyPair) {
        this.pairing = pairing;
        this.settingParameters = settingParameters;
        this.keyPair = keyPair;
    }

    public Pairing getPairing() {
        return pairing;
    }

    public SettingParameters getSettingParameters() {
        return settingParameters;
    }

    public KeyPair getKeyPair() {
        return keyPair;
    }
}
